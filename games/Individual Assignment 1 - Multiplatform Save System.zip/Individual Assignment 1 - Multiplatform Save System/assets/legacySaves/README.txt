LEGACY SAVES - Individual Assignment 1 (Laboratorio Multiplataforma 2026-27)

Save files written by the previous releases of the game. Detect the version from the CONTENT, not from the name.

The version folders (v1.0 and v1.1) are selfexplanatory.

future folder save version 4 (game 1.3). Must be REFUSED with a message and never overwritten without the player's confirmation.
