#pragma once

#include <XEngine.h>
#include "../scripts/UI/MainMenu.hpp"

/** Construye el menú principal y el panel de opciones que comparte con el juego. */
inline void BuildMainMenuScene(Scene* scene)
{
    if (!scene) return;
    Renderer->ClearParallax();
    Renderer->ClearBackground();

    MainMenu* menu = nullptr;
    if (GameObject* object = scene->CreateObject("MainMenu"))
        menu = object->AddComponent<MainMenu>();

    OptionsPanel* options = CreateOptionsPanel(*scene);
    if (menu) menu->optionsPanel = options;
}
