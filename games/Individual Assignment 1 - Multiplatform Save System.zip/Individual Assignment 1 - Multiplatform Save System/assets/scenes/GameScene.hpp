#pragma once
#include <XEngine.h>

inline void BuildGameScene(Scene* scene)
{
    if (!scene) return;

    
}
