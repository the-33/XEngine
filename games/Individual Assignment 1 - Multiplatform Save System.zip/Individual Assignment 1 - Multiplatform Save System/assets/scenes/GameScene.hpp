#pragma once
#include <XEngine.h>
#include "../scripts/Save/GameSceneState.hpp"
#include "../scripts/Player/PlayerCamera.hpp"
#include "../scripts/Player/PlayerHUD.hpp"
#include "../scripts/UI/GamePauseMenu.hpp"

#include <string>
#include <utility>

inline void BuildGameScene(Scene* scene)
{
    if (!scene) return;

    // La textura del suelo se repite sin crear un GameObject por baldosa.
    Renderer->ClearBackground();
    Renderer->ClearParallax();
    if (Texture* floor = Assets->LoadTexture("textures/ground_tile.png", 128.f)) {
        RenderManager::BackgroundLayer tile{};
        tile.tex = floor;
        tile.mode = RenderManager::BackgroundMode::TileWorldPhysical;
        tile.order = 0;
        tile.seamSafe = true;
        Renderer->AddParallaxLayer(tile);
    }

    // Se reconstruye la partida pendiente o se genera un nivel nuevo.
    std::optional<GameSaveData> loaded = GameSession::Get().TakeStartState();
    // Las preferencias globales se gestionan por PlayerPrefs, fuera del slot.
    if (!loaded && !GameSession::Get().TakePreparedNewGame()) {
        GameSession::Get().QueueNewGame();
        (void)GameSession::Get().TakePreparedNewGame();
    }

    const std::string newGameName = GameSession::Get().TakeNewGameName();
    const std::string name = (loaded && !loaded->player.name.empty())
        ? loaded->player.name : newGameName;
    const Vec3 position = loaded ? loaded->player.position : Vec3{0.f, 0.f, 0.f};

    // Con la misma Z, el orden de creación mantiene el jugador por delante.
    if (loaded) RestoreLevel(*scene, loaded->level);
    else GenerateNewLevel(*scene);

    GameObject* player = CreatePlayer(*scene, name, position);
    if (player) {
        if (loaded) RestorePlayer(*player, loaded->player);
        player->AddComponent<PlayerCamera>();
    }

    // Los metadatos cargados se conservan; en una partida nueva parten de cero.
    if (loaded) GameSession::Get().SetCurrent(std::move(*loaded));
    else GameSession::Get().SetCurrent(CaptureGameScene(*scene));

    if (GameObject* ui = scene->CreateObject("GameHUD")) {
        PlayerHUD* hud = ui->AddComponent<PlayerHUD>();
        hud->player = player;
    }

    // El controlador de pausa escucha Escape incluso con el panel oculto.
    GamePauseMenu* pauseMenu = nullptr;
    if (GameObject* ui = scene->CreateObject("GamePauseMenu"))
        pauseMenu = ui->AddComponent<GamePauseMenu>();

    OptionsPanel* options = CreateOptionsPanel(*scene);
    if (pauseMenu) pauseMenu->optionsPanel = options;
}
