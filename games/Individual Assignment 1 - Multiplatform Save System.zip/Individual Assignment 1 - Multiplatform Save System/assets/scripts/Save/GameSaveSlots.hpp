#pragma once

#include <XEngine/Storage.h>

#include <filesystem>
#include <string>

/** Rutas de los tres slots almacenados en los datos persistentes del usuario. */
class GameSaveSlots final
{
public:
    static constexpr int Count = 3;

    /** Obtiene la carpeta privada de guardados del juego. */
    [[nodiscard]] static std::filesystem::path Directory()
    {
        return FileSystem::GetPersistentDataPath("XEngine", "IndividualAssignment1");
    }

    /**
     * Resuelve el archivo slot1.sav, slot2.sav o slot3.sav.
     * @param slot Número de slot, entre 1 y 3.
     * @return Ruta completa, o vacía si no hay carpeta o el índice es incorrecto.
     */
    [[nodiscard]] static std::filesystem::path PathFor(int slot)
    {
        if (slot < 1 || slot > Count) return {};
        const auto folder = Directory();
        if (folder.empty()) return {};
        return folder / ("slot" + std::to_string(slot) + ".sav");
    }

    /**
     * Comprueba que ninguna de las tres variantes del archivo ocupa el slot.
     * @param slot Número de slot, entre 1 y 3.
     * @return True solo si puede utilizarse para una partida nueva.
     */
    [[nodiscard]] static bool IsFree(int slot)
    {
        const auto path = PathFor(slot);
        if (path.empty()) return false;
        const auto files = AtomicFile::Inspect(path);
        return files.error == FileError::None &&
               !files.primary && !files.backup && !files.temporary;
    }
};
