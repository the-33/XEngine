#pragma once

#include "GameSceneState.hpp"
#include "GameSaveMigrations.hpp"
#include "SaveChecksum.hpp"

#include <XEngine/Platform.h>
#include <XEngine/Storage.h>

#include <array>
#include <chrono>
#include <cmath>
#include <cstddef>
#include <cstdint>
#include <ctime>
#include <filesystem>
#include <optional>
#include <span>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

/** Resultado de una operación de guardado o carga de partida. */
enum class GameSaveStatus {
    Ok,
    NoPath,
    NotFound,
    InvalidFile,
    FutureVersion,
    IoError
};

struct GameSaveResult
{
    GameSaveStatus status = GameSaveStatus::InvalidFile;
    std::string message{};
    std::filesystem::path path{};
    std::uint32_t sourceVersion = 0;
    bool usedBackup = false;
    bool usedTemporary = false;

    /** Indica si la operación se completó, incluso si necesitó recuperar otro archivo. */
    [[nodiscard]] bool Ok() const noexcept { return status == GameSaveStatus::Ok; }
};

/** Lectura y escritura de slots v3 con migración de los archivos anteriores. */
class GameSaveFiles final
{
public:
    static constexpr std::uint32_t CurrentVersion = 3;
    static constexpr std::size_t HeaderSize = 44; // Firma, versión, longitud y SHA-256.
    static constexpr std::uint64_t MaxFileBytes = 8u * 1024u * 1024u;

    /**
     * Lee un slot y prepara su contenido para la siguiente GameScene.
     * @param path Ruta obligatoria del slot; puede contener v1, v2 o v3.
     * @return Estado de la carga, incluida la recuperación desde .bak o .tmp.
     */
    static GameSaveResult Load(const std::filesystem::path& path)
    {
        GameSaveData loaded{};
        GameSaveResult result = ReadSlot(path, loaded);
        if (result.Ok())
            GameSession::Get().QueueLoadedGame(std::move(loaded), path);
        return result;
    }

    /**
     * Lee el contenido sin modificar la sesión; sirve para mostrar los slots del menú.
     * @param path Ruta completa del archivo a consultar.
     * @param output Recibe la partida únicamente si se ha podido validar.
     * @param restoreTemporary Permite promocionar un temporal válido a archivo principal.
     * @return Estado, versión original y origen primario, backup o temporal.
     */
    static GameSaveResult ReadSlot(const std::filesystem::path& path, GameSaveData& output,
                                   bool restoreTemporary = true)
    {
        if (path.empty() || path.filename().empty())
            return {GameSaveStatus::NoPath, "No save slot selected", path};

        const AtomicFileInspection files = AtomicFile::Inspect(path);
        if (files.error != FileError::None)
            return {GameSaveStatus::IoError, "Cannot inspect save files", path};
        if (!files.primary && !files.backup && !files.temporary)
            return {GameSaveStatus::NotFound, "Save file not found", path};

        GameSaveResult primaryError{GameSaveStatus::InvalidFile, "Invalid save file", path};
        if (files.primary) {
            primaryError = ReadCandidate(path, AtomicFileSource::Primary, output);
            if (primaryError.Ok() || primaryError.status == GameSaveStatus::FutureVersion)
                return primaryError;
        }
        if (files.backup) {
            GameSaveData backup{};
            GameSaveResult recovered = ReadCandidate(path, AtomicFileSource::Backup, backup);
            if (recovered.Ok()) {
                output = std::move(backup);
                recovered.usedBackup = true;
                recovered.message = "Save recovered from backup";
                return recovered;
            }
            // Un archivo futuro no se trata como corrupción y nunca se degrada.
            if (recovered.status == GameSaveStatus::FutureVersion) return recovered;
            if (!files.primary) primaryError = std::move(recovered);
            else primaryError.message += "; backup also invalid: " + recovered.message;
        }

        if (files.temporary) {
            GameSaveData pending{};
            GameSaveResult recovered = ReadCandidate(path, AtomicFileSource::Temporary, pending);
            if (recovered.Ok()) {
                if (restoreTemporary) {
                    const FileError restoreError = RestoreTemporary(path, files);
                    if (restoreError != FileError::None)
                        return {GameSaveStatus::IoError, "Valid temporary save could not be restored", path};
                }
                output = std::move(pending);
                recovered.usedTemporary = true;
                recovered.message = restoreTemporary
                    ? "Save restored from temporary file"
                    : "Save loaded from temporary file without restoring it";
                return recovered;
            }
            if (recovered.status == GameSaveStatus::FutureVersion) return recovered;
            if (!files.primary && !files.backup) return recovered;
            primaryError.message += "; temporary also invalid: " + recovered.message;
        }
        return primaryError;
    }

    /**
     * Escribe un archivo v3 con la fecha actual y crea una copia .bak al reemplazarlo.
     * @param data Captura de la partida; su fecha se actualiza al escribir.
     * @param path Ruta opcional. Vacía utiliza la última ruta de la sesión.
     * @param confirmFutureOverwrite Permite reemplazar un archivo futuro solo tras confirmación expresa.
     * @return Estado de la escritura atómica.
     */
    static GameSaveResult Save(GameSaveData data, std::filesystem::path path = {},
                               bool confirmFutureOverwrite = false)
    {
        if (path.empty()) path = GameSession::Get().SavePath();
        if (path.empty() || path.filename().empty())
            return {GameSaveStatus::NoPath, "No save slot selected", path};
        try {
            const auto files = AtomicFile::Inspect(path);
            if (files.error != FileError::None)
                return {GameSaveStatus::IoError, "Cannot inspect save slot", path};
            if (!confirmFutureOverwrite && (IsFutureFile(path, AtomicFileSource::Primary, files.primary) ||
                                            IsFutureFile(path, AtomicFileSource::Backup, files.backup)))
                return {GameSaveStatus::FutureVersion, "Save belongs to a newer game version", path};

            data.metadata.savedAtUtc = UtcNow();
            if (!ValidData(data))
                return {GameSaveStatus::InvalidFile, "Game state contains invalid values", path};

#if defined(XENGINE_PLATFORM_WINDOWS)
            const std::string json = JsonSerializer::Serialize(data);
            const auto* first = reinterpret_cast<const std::byte*>(json.data());
            const std::vector<std::byte> payload(first, first + json.size());
#elif defined(XENGINE_PLATFORM_LINUX)
            // Linux utiliza la serialización binaria del motor.
            const std::vector<std::byte> payload = BinarySerializer::Serialize(data);
#else
#error "GameSaveFiles solo admite Windows y Linux"
#endif
            if (payload.size() > MaxFileBytes - HeaderSize)
                return {GameSaveStatus::InvalidFile, "Save payload exceeds size limit", path};

            BinaryWriter writer;
            writer.WriteBytes("SAVE", 4);
            writer.WriteUInt32(CurrentVersion);
            writer.WriteUInt32(static_cast<std::uint32_t>(payload.size()));
            const auto checksum = SaveChecksum::Sha256(payload);
            writer.WriteBytes(checksum);
            writer.WriteBytes(payload);
            const auto bytes = writer.TakeData();
            const FileError error = AtomicFile::Write(path, bytes);
            if (error != FileError::None)
                return {GameSaveStatus::IoError,
                        error == FileError::RecoveryRequired
                            ? "Previous interrupted write needs recovery (.tmp exists)"
                            : "Failed to write save file", path};
            GameSession::Get().SetSavePath(path);
            GameSession::Get().SetCurrent(std::move(data));
            return {GameSaveStatus::Ok, "Game saved", path, CurrentVersion};
        } catch (const std::exception& error) {
            return {GameSaveStatus::IoError, std::string("Save failed: ") + error.what(), path};
        }
    }

    /**
     * Captura el estado vivo exclusivamente al pulsar Save.
     * @param scene Escena cuyos objetos se van a serializar.
     * @param path Ruta opcional; por defecto se usa el slot de la sesión.
     * @return Resultado de Save, sin modificar la escena si hay un error.
     */
    static GameSaveResult SaveScene(Scene& scene, std::filesystem::path path = {})
    {
        return Save(CaptureGameScene(scene), std::move(path));
    }

private:
    /**
     * Publica un temporal ya validado sin eliminar el archivo dañado anterior.
     * @param path Ruta principal del slot.
     * @param files Estado de los candidatos antes de la recuperación.
     * @return Resultado del traslado del temporal a la ruta principal.
     */
    static FileError RestoreTemporary(const std::filesystem::path& path,
                                      const AtomicFileInspection& files)
    {
        if (files.primary) {
            // La copia dañada queda accesible para un diagnóstico posterior.
            bool preserved = false;
            for (unsigned attempt = 0; attempt < 100; ++attempt) {
                std::filesystem::path destination = path;
                destination += attempt == 0 ? ".corrupt" : ".corrupt." + std::to_string(attempt);
                if (FileSystem::Exists(destination)) continue;
                const FileError error = FileSystem::Copy(files.primaryPath, destination);
                if (error == FileError::AlreadyExists) continue;
                if (error != FileError::None) return error;
                preserved = true;
                break;
            }
            if (!preserved) return FileError::AlreadyExists;
        }
        // AtomicFile no promueve candidatos: el traslado conserva el .bak y
        // reutiliza el .tmp ya validado en la misma carpeta.
        return FileSystem::Move(files.temporaryPath, files.primaryPath, files.primary);
    }

    /** Convierte fechas del sistema a ISO 8601 en UTC, sin depender de la zona local. */
    static std::string UtcTime(std::chrono::system_clock::time_point when)
    {
        const std::time_t value = std::chrono::system_clock::to_time_t(when);
        std::tm utc{};
#if defined(XENGINE_PLATFORM_WINDOWS)
        gmtime_s(&utc, &value);
#elif defined(XENGINE_PLATFORM_LINUX)
        gmtime_r(&value, &utc);
#else
#error "GameSaveFiles solo admite Windows y Linux"
#endif
        char buffer[32]{};
        if (std::strftime(buffer, sizeof buffer, "%Y-%m-%dT%H:%M:%SZ", &utc) == 0)
            throw std::runtime_error("Cannot format UTC timestamp");
        return buffer;
    }

    static std::string UtcNow() { return UtcTime(std::chrono::system_clock::now()); }

    /** Toma la fecha de modificación del archivo legado original. */
    static std::string LegacyDate(const std::filesystem::path& file)
    {
        std::error_code error;
        const auto modified = std::filesystem::last_write_time(file, error);
        if (error) return {};
        return UtcTime(std::chrono::file_clock::to_sys(modified));
    }

    static std::string_view AsText(std::span<const std::byte> bytes)
    {
        return {reinterpret_cast<const char*>(bytes.data()), bytes.size()};
    }

    /** Lee la versión 1 con el formato correspondiente a la plataforma. */
    static GameSaveMigrations::Version1 ReadVersion1(std::span<const std::byte> bytes)
    {
#if defined(XENGINE_PLATFORM_WINDOWS)
        return GameSaveMigrations::ReadVersion1Json(AsText(bytes));
#elif defined(XENGINE_PLATFORM_LINUX)
        return GameSaveMigrations::ReadVersion1Binary(bytes);
#else
#error "GameSaveFiles solo admite Windows y Linux"
#endif
    }

    /** Lee la versión 2 con el formato correspondiente a la plataforma. */
    static GameSaveMigrations::Version2 ReadVersion2(std::span<const std::byte> bytes)
    {
#if defined(XENGINE_PLATFORM_WINDOWS)
        return GameSaveMigrations::ReadVersion2Json(AsText(bytes));
#elif defined(XENGINE_PLATFORM_LINUX)
        return GameSaveMigrations::ReadVersion2Binary(bytes);
#else
#error "GameSaveFiles solo admite Windows y Linux"
#endif
    }

    /** Lee la versión actual usando el serializador propio de cada plataforma. */
    static GameSaveData ReadVersion3(std::span<const std::byte> bytes)
    {
#if defined(XENGINE_PLATFORM_WINDOWS)
        return JsonSerializer::Deserialize<GameSaveData>(AsText(bytes));
#elif defined(XENGINE_PLATFORM_LINUX)
        return BinarySerializer::Deserialize<GameSaveData>(bytes);
#else
#error "GameSaveFiles solo admite Windows y Linux"
#endif
    }

    /** Comprueba los campos que pueden provocar posiciones o contadores inválidos. */
    static bool ValidData(const GameSaveData& data)
    {
        const auto finite = [](Vec3 value) {
            return std::isfinite(value.x) && std::isfinite(value.y) && std::isfinite(value.z);
        };
        if (data.player.name.size() > 4096 || !finite(data.player.position) ||
            !std::isfinite(data.player.health) || data.player.health < 0.f ||
            data.player.health > 1.f || !std::isfinite(data.metadata.playTimeSeconds) ||
            data.metadata.playTimeSeconds < 0.0 || data.level.pickups.size() > 4096 ||
            data.level.spikes.size() > 4096) return false;
        for (const auto& pickup : data.level.pickups)
            if (!finite(pickup.position) || pickup.type.size() > 128) return false;
        for (const auto& spike : data.level.spikes)
            if (!finite(spike)) return false;
        return true;
    }

    /** Devuelve la versión de una cabecera SAVE, incluso si el resto está dañado. */
    static std::uint32_t PeekVersion(std::span<const std::byte> bytes)
    {
        if (bytes.size() < 8 || bytes[0] != std::byte{'S'} ||
            bytes[1] != std::byte{'A'} || bytes[2] != std::byte{'V'} ||
            bytes[3] != std::byte{'E'}) return 1;
        BinaryReader reader(bytes);
        (void)reader.ReadUInt32(); // La firma ya se ha comprobado.
        return reader.ReadUInt32();
    }

    static bool IsFutureFile(const std::filesystem::path& path, AtomicFileSource source, bool exists)
    {
        if (!exists) return false;
        const auto read = AtomicFile::Read(path, source, MaxFileBytes);
        return read.Ok() && PeekVersion(read.data) > CurrentVersion;
    }

    /** Interpreta un candidato sin alterar la partida en caso de error. */
    static GameSaveResult ReadCandidate(const std::filesystem::path& path,
                                        AtomicFileSource source, GameSaveData& output)
    {
        const auto read = AtomicFile::Read(path, source, MaxFileBytes);
        if (!read.Ok())
            return {GameSaveStatus::IoError, "Cannot read save candidate", path};
        try {
            const std::span<const std::byte> file = read.data;
            const auto version = PeekVersion(file);
            if (version > CurrentVersion)
                return {GameSaveStatus::FutureVersion, "Save belongs to a newer game version", path, version};

            std::span<const std::byte> payload = file;
            if (version != 1) {
                if (version != 2 && version != CurrentVersion)
                    throw std::runtime_error("Unsupported save version");
                if (file.size() < HeaderSize)
                    throw std::runtime_error("Truncated save header");
                BinaryReader header(file);
                (void)header.ReadUInt32(); // SAVE
                (void)header.ReadUInt32(); // Versión ya validada.
                const auto length = header.ReadUInt32();
                if (length != file.size() - HeaderSize)
                    throw std::runtime_error("Incorrect payload length");
                std::array<std::byte, 32> expected{};
                header.ReadBytes(expected);
                payload = file.subspan(HeaderSize, length);
                if (SaveChecksum::Sha256(payload) != expected)
                    throw std::runtime_error("Checksum mismatch (SHA-256)");
            }

            GameSaveData decoded{};
            const auto origin = source == AtomicFileSource::Backup
                ? AtomicFile::BackupPath(path)
                : source == AtomicFileSource::Temporary
                    ? AtomicFile::TemporaryPath(path) : path;
            if (version == 1) {
                const auto legacy = ReadVersion1(payload);
                decoded = GameSaveMigrations::Migrate2To3(
                    GameSaveMigrations::Migrate1To2(legacy),
                    LegacyDate(origin));
            } else if (version == 2) {
                const auto legacy = ReadVersion2(payload);
                decoded = GameSaveMigrations::Migrate2To3(legacy, LegacyDate(origin));
            } else {
                decoded = ReadVersion3(payload);
            }
            if (!ValidData(decoded)) throw std::runtime_error("Invalid game state");
            output = std::move(decoded);
            return {GameSaveStatus::Ok, "Game loaded", path, version};
        } catch (const std::exception& error) {
            return {GameSaveStatus::InvalidFile, std::string("Corrupt save file: ") + error.what(), path};
        }
    }
};
