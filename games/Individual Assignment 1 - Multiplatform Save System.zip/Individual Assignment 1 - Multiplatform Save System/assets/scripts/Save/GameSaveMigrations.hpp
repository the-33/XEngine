#pragma once

#include "GameSaveData.hpp"

#include <algorithm>
#include <cstdint>
#include <stdexcept>
#include <string>
#include <string_view>
#include <utility>
#include <vector>

namespace GameSaveMigrations {

/** Datos de la versión 1: sin cabecera, wallet ni tipos de coleccionables. */
struct Version1
{
    std::string name;
    std::int32_t health = 100;
    Vec3 position{};
    std::vector<Vec3> pickups{};
};

/** Datos de la versión 2: salud entera y tipos Coin(0), Gem(1), Key(2). */
struct Version2
{
    struct Pickup { std::int32_t type = 0; Vec3 position{}; };
    std::string name;
    std::int32_t health = 100;
    std::int32_t coins = 0;
    std::int32_t gems = 0;
    Vec3 position{};
    std::vector<Pickup> pickups{};
};

/** Lee el formato histórico de Windows, que usaba coordenadas planas. */
inline Version1 ReadVersion1Json(std::string_view text)
{
    const auto json = nlohmann::json::parse(text);
    Version1 old{};
    old.name = json.at("name").get<std::string>();
    old.health = json.at("health").get<std::int32_t>();
    old.position = {json.at("posX").get<float>(), json.at("posY").get<float>(),
                    json.at("posZ").get<float>()};
    const auto& pickups = json.at("pickups");
    if (!pickups.is_array() || pickups.size() > 4096) throw std::runtime_error("Invalid v1 pickups");
    for (const auto& p : pickups)
        old.pickups.push_back({p.at("x").get<float>(), p.at("y").get<float>(),
                               p.at("z").get<float>()});
    return old;
}

/** Lee los campos binarios de la versión 1 en su orden original. */
inline Version1 ReadVersion1Binary(std::span<const std::byte> bytes)
{
    BinaryReader reader(bytes);
    Version1 old{};
    old.name = reader.ReadString();
    old.health = reader.ReadInt32();
    old.position = {reader.ReadFloat32(), reader.ReadFloat32(), reader.ReadFloat32()};
    const auto count = reader.ReadInt32();
    if (count < 0 || count > 4096) throw std::runtime_error("Invalid v1 pickup count");
    for (int i = 0; i < count; ++i)
        old.pickups.push_back({reader.ReadFloat32(), reader.ReadFloat32(), reader.ReadFloat32()});
    if (reader.RemainingBytes() != 0) throw std::runtime_error("Unexpected v1 trailing bytes");
    return old;
}

/** Lee el JSON con cabecera de la versión 2. */
inline Version2 ReadVersion2Json(std::string_view text)
{
    const auto json = nlohmann::json::parse(text);
    Version2 old{};
    old.name = json.at("name").get<std::string>();
    old.health = json.at("health").get<std::int32_t>();
    old.coins = json.at("coins").get<std::int32_t>();
    old.gems = json.at("gems").get<std::int32_t>();
    const auto& p = json.at("position");
    old.position = {p.at("x").get<float>(), p.at("y").get<float>(), p.at("z").get<float>()};
    const auto& pickups = json.at("pickups");
    if (!pickups.is_array() || pickups.size() > 4096) throw std::runtime_error("Invalid v2 pickups");
    for (const auto& pickup : pickups) {
        const auto& pos = pickup.at("position");
        old.pickups.push_back({pickup.at("type").get<std::int32_t>(),
                              {pos.at("x").get<float>(), pos.at("y").get<float>(),
                               pos.at("z").get<float>()}});
    }
    return old;
}

/** Lee el formato binario de la versión 2 sin depender del sistema operativo. */
inline Version2 ReadVersion2Binary(std::span<const std::byte> bytes)
{
    BinaryReader reader(bytes);
    Version2 old{};
    old.name = reader.ReadString();
    old.health = reader.ReadInt32();
    old.coins = reader.ReadInt32();
    old.gems = reader.ReadInt32();
    old.position = {reader.ReadFloat32(), reader.ReadFloat32(), reader.ReadFloat32()};
    const auto count = reader.ReadInt32();
    if (count < 0 || count > 4096) throw std::runtime_error("Invalid v2 pickup count");
    for (int i = 0; i < count; ++i) {
        Version2::Pickup pickup{};
        pickup.type = reader.ReadInt32();
        pickup.position = {reader.ReadFloat32(), reader.ReadFloat32(), reader.ReadFloat32()};
        old.pickups.push_back(pickup);
    }
    if (reader.RemainingBytes() != 0) throw std::runtime_error("Unexpected v2 trailing bytes");
    return old;
}

/** Primera migración: incorpora wallet vacía y asigna Coin a los pickups. */
inline Version2 Migrate1To2(const Version1& old)
{
    Version2 next{};
    next.name = old.name;
    next.health = old.health;
    next.position = old.position;
    for (const Vec3& position : old.pickups)
        next.pickups.push_back({0, position});
    return next;
}

/** Segunda migración: normaliza la salud y traslada los contadores a Wallet. */
inline GameSaveData Migrate2To3(const Version2& old, std::string savedAtUtc)
{
    GameSaveData next{};
    next.player.name = old.name;
    next.player.health = std::clamp(static_cast<float>(old.health) / 100.f, 0.f, 1.f);
    next.player.position = old.position;
    next.player.wallet.coins = static_cast<std::uint32_t>(std::max(0, old.coins));
    next.player.wallet.gems = static_cast<std::uint32_t>(std::max(0, old.gems));
    for (const auto& pickup : old.pickups) {
        if (pickup.type < 0 || pickup.type > 2)
            throw std::runtime_error("Unknown v2 pickup type");
        // Key ya no existe en la versión 3; se representa como Coin.
        const char* type = pickup.type == 1 ? "Gem" : "Coin";
        next.level.pickups.push_back({type, pickup.position});
    }
    next.metadata.savedAtUtc = std::move(savedAtUtc);
    next.metadata.playTimeSeconds = 0.0;
    return next;
}

}
