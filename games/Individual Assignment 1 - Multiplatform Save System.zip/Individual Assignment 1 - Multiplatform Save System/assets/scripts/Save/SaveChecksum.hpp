#pragma once

// Implementación autónoma de SHA-256 para las cabeceras de guardado.

#include <array>
#include <bit>
#include <cstddef>
#include <cstdint>
#include <span>
#include <tuple>
#include <vector>

namespace SaveChecksum {

/** Calcula el resumen SHA-256 del contenido, en 32 bytes sin codificar. */
inline std::array<std::byte, 32> Sha256(std::span<const std::byte> payload)
{
    constexpr std::array<std::uint32_t, 64> k{
        0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
        0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
        0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
        0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
        0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
        0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
        0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
        0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
    };
    std::array<std::uint32_t, 8> state{
        0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
        0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19
    };

    // El relleno termina con la longitud original en bits y orden big-endian.
    std::vector<std::uint8_t> input;
    input.reserve(((payload.size() + 9 + 63) / 64) * 64);
    for (std::byte byte : payload) input.push_back(std::to_integer<std::uint8_t>(byte));
    input.push_back(0x80);
    while (input.size() % 64 != 56) input.push_back(0);
    const std::uint64_t bits = static_cast<std::uint64_t>(payload.size()) * 8;
    for (int i = 7; i >= 0; --i) input.push_back(static_cast<std::uint8_t>(bits >> (8 * i)));

    for (std::size_t offset = 0; offset < input.size(); offset += 64) {
        std::array<std::uint32_t, 64> words{};
        for (unsigned i = 0; i < 16; ++i) {
            const auto p = offset + i * 4;
            words[i] = (std::uint32_t(input[p]) << 24) |
                       (std::uint32_t(input[p + 1]) << 16) |
                       (std::uint32_t(input[p + 2]) << 8) | std::uint32_t(input[p + 3]);
        }
        for (unsigned i = 16; i < 64; ++i) {
            const auto x = words[i - 15], y = words[i - 2];
            const auto s0 = std::rotr(x, 7) ^ std::rotr(x, 18) ^ (x >> 3);
            const auto s1 = std::rotr(y, 17) ^ std::rotr(y, 19) ^ (y >> 10);
            words[i] = words[i - 16] + s0 + words[i - 7] + s1;
        }
        auto [a,b,c,d,e,f,g,h] = std::tuple{state[0],state[1],state[2],state[3],state[4],state[5],state[6],state[7]};
        for (unsigned i = 0; i < 64; ++i) {
            const auto s1 = std::rotr(e, 6) ^ std::rotr(e, 11) ^ std::rotr(e, 25);
            const auto choose = (e & f) ^ (~e & g);
            const auto t1 = h + s1 + choose + k[i] + words[i];
            const auto s0 = std::rotr(a, 2) ^ std::rotr(a, 13) ^ std::rotr(a, 22);
            const auto majority = (a & b) ^ (a & c) ^ (b & c);
            const auto t2 = s0 + majority;
            h = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
        }
        state[0] += a; state[1] += b; state[2] += c; state[3] += d;
        state[4] += e; state[5] += f; state[6] += g; state[7] += h;
    }
    std::array<std::byte, 32> digest{};
    for (unsigned i = 0; i < 8; ++i)
        for (unsigned j = 0; j < 4; ++j)
            digest[4 * i + j] = std::byte(state[i] >> (24 - 8 * j));
    return digest;
}

}
