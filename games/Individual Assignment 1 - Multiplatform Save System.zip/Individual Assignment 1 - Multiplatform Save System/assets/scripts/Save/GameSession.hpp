#pragma once

#include "GameSaveData.hpp"

#include <optional>
#include <cmath>
#include <filesystem>
#include <string>
#include <utility>
#include <vector>

// Conserva los datos de la partida entre escenas sin guardar punteros a GameObjects.
class GameSession final
{
public:
    static GameSession& Get() noexcept
    {
        static GameSession instance;
        return instance;
    }

    /** Prepara la carga de una partida y recuerda el archivo de origen. */
    void QueueLoadedGame(GameSaveData data, std::filesystem::path path = {})
    {
        unrecognizedPickups_.clear();
        pendingNewGameName_.clear();
        pendingLoad_ = std::move(data);
        savePath_ = std::move(path);
        newGamePending_ = false;
    }

    /** Prepara una partida nueva y asocia el slot que recibirá el primer guardado. */
    void QueueNewGame(std::filesystem::path path = {}, std::string name = "Player")
    {
        pendingLoad_.reset();
        current_.reset();
        unrecognizedPickups_.clear();
        savePath_ = std::move(path);
        pendingNewGameName_ = std::move(name);
        newGamePending_ = true;
    }

    /** Entrega el nombre elegido al construir por primera vez la escena. */
    [[nodiscard]] std::string TakeNewGameName()
    {
        std::string name = std::move(pendingNewGameName_);
        pendingNewGameName_.clear();
        return name.empty() ? "Player" : name;
    }

    /** Consume la selección de nueva partida al construir la escena de juego. */
    [[nodiscard]] bool TakePreparedNewGame() noexcept
    {
        const bool result = newGamePending_;
        newGamePending_ = false;
        return result;
    }

    [[nodiscard]] std::optional<GameSaveData> TakeStartState()
    {
        std::optional<GameSaveData> result = std::move(pendingLoad_);
        pendingLoad_.reset();
        return result;
    }

    void SetCurrent(GameSaveData data)
    {
        current_ = std::move(data);
    }

    // El contador de tiempo se actualiza sin hacer capturas de la escena.
    void AdvancePlayTime(double seconds) noexcept
    {
        if (current_ && std::isfinite(seconds) && seconds > 0.0)
            current_->metadata.playTimeSeconds += seconds;
    }

    [[nodiscard]] const GameSaveData* Current() const noexcept
    {
        return current_ ? &*current_ : nullptr;
    }

    /** Ruta del último archivo cargado o guardado explícitamente. */
    [[nodiscard]] const std::filesystem::path& SavePath() const noexcept { return savePath_; }

    /** Asocia una ruta al slot actual sin escribir todavía el archivo. */
    void SetSavePath(std::filesystem::path path) { savePath_ = std::move(path); }

    // Los tipos de pickup desconocidos se conservan aunque no se dibujen.
    void KeepUnrecognizedPickup(const PickupSaveData& pickup)
    {
        unrecognizedPickups_.push_back(pickup);
    }

    [[nodiscard]] const std::vector<PickupSaveData>& UnrecognizedPickups() const noexcept
    {
        return unrecognizedPickups_;
    }

private:
    GameSession() = default;

    std::optional<GameSaveData> pendingLoad_{};
    std::optional<GameSaveData> current_{};
    std::vector<PickupSaveData> unrecognizedPickups_{};
    std::filesystem::path savePath_{};
    std::string pendingNewGameName_{};
    bool newGamePending_ = false;
};
