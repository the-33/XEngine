#pragma once

#include <XEngine.h>
#include <XEngine/Serialization.h>
#include "../Player/PlayerData.hpp"

#include <string>
#include <vector>

// Payload de la versión 3. Las preferencias globales van por PlayerPrefs.

struct PickupSaveData
{
    // El nombre evita que un tipo nuevo altere los identificadores anteriores.
    std::string type = "Coin"; // Coin, Heart o Gem.
    Vec3 position{};

    XENGINE_SERIALIZABLE(type, position)
};

struct LevelSaveData
{
    // Solo aparecen los coleccionables que quedan en el mundo.
    std::vector<PickupSaveData> pickups{};

    // También se conservan los pinchos para reconstruir el nivel.
    std::vector<Vec3> spikes{};

    XENGINE_SERIALIZABLE(pickups, spikes)
};

struct SlotMetadataSaveData
{
    // La fecha se asigna al escribir el archivo.
    std::string savedAtUtc{};           // UTC en ISO 8601, p. ej. 2026-10-31T15:40:00Z.
    double playTimeSeconds = 0.0;

    XENGINE_SERIALIZABLE(savedAtUtc, playTimeSeconds)
};

struct GameSaveData
{
    PlayerData player{};                // Nombre, vida, posición y wallet.
    LevelSaveData level{};              // Coleccionables y obstáculos restantes.
    SlotMetadataSaveData metadata{};    // Fecha y tiempo total de juego.

    XENGINE_SERIALIZABLE(player, level, metadata)
};
