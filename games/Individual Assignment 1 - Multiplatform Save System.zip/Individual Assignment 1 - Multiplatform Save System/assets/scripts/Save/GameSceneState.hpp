#pragma once

#include "GameSession.hpp"
#include "../../gameobjects/Player.hpp"
#include "../../gameobjects/Coin.hpp"
#include "../../gameobjects/Gem.hpp"
#include "../../gameobjects/Heart.hpp"
#include "../../gameobjects/Spike.hpp"

#include <algorithm>
#include <cmath>
#include <cstdio>
#include <string>
#include <utility>
#include <vector>

inline GameObject* FindScenePlayer(Scene& scene)
{
    for (const auto& object : scene.GetEntities()) {
        if (object && object->tag.get() == "Player") return object.get();
    }
    return nullptr;
}

// La captura utiliza los objetos actuales, incluidos los coleccionables restantes.
inline GameSaveData CaptureGameScene(Scene& scene)
{
    GameSaveData snapshot{};
    if (const auto* previous = GameSession::Get().Current())
        snapshot.metadata = previous->metadata;

    if (GameObject* player = FindScenePlayer(scene))
        snapshot.player = CapturePlayer(*player);

    for (const auto& object : scene.GetEntities()) {
        if (!object) continue;
        const std::string tag = object->tag.get();
        const Vec3 position = object->transform->position.get();
        if (tag == "Coin" || tag == "Heart" || tag == "Gem")
            snapshot.level.pickups.push_back(PickupSaveData{tag, position});
        else if (tag == "Spike")
            snapshot.level.spikes.push_back(position);
    }
    const auto& unknown = GameSession::Get().UnrecognizedPickups();
    snapshot.level.pickups.insert(snapshot.level.pickups.end(), unknown.begin(), unknown.end());
    return snapshot;
}

inline void RestoreLevel(Scene& scene, const LevelSaveData& level)
{
    // Se limitan los objetos y se descartan posiciones no finitas.
    const auto finite = [](Vec3 p) {
        return std::isfinite(p.x) && std::isfinite(p.y) && std::isfinite(p.z);
    };

    const size_t pickupCount = std::min(level.pickups.size(), size_t{4096});
    for (size_t i = 0; i < pickupCount; ++i) {
        const PickupSaveData& item = level.pickups[i];
        if (!finite(item.position)) continue;
        if (item.type == "Coin") CreateCoin(scene, item.position);
        else if (item.type == "Heart") CreateHeart(scene, item.position);
        else if (item.type == "Gem") CreateGem(scene, item.position);
        else {
            GameSession::Get().KeepUnrecognizedPickup(item);
            std::fprintf(stderr, "[SAVE] Tipo de pickup desconocido: %s\n", item.type.c_str());
        }
    }

    const size_t spikeCount = std::min(level.spikes.size(), size_t{4096});
    for (size_t i = 0; i < spikeCount; ++i)
        if (finite(level.spikes[i])) CreateSpike(scene, level.spikes[i]);
}

/** Genera los datos iniciales del nivel sin depender de una escena activa. */
inline LevelSaveData GenerateNewLevelData()
{
    // La cuadrícula barajada evita solapamientos cerca del origen.
    std::vector<Vec3> cells;
    for (int y = -4; y <= 4; ++y)
        for (int x = -8; x <= 8; ++x)
            if (std::abs(x) > 1 || std::abs(y) > 1)
                cells.push_back(Vec3{static_cast<float>(x), static_cast<float>(y), 0.f});

    for (size_t i = cells.size(); i > 1; --i)
        std::swap(cells[i - 1], cells[static_cast<size_t>(Random->Range(0, static_cast<int>(i)))]);

    LevelSaveData level{};
    size_t next = 0;
    for (int i = 0; i < 5; ++i) level.pickups.push_back({"Coin", cells[next++]});
    for (int i = 0; i < 4; ++i) level.pickups.push_back({"Gem", cells[next++]});
    for (int i = 0; i < 3; ++i) level.pickups.push_back({"Heart", cells[next++]});
    for (int i = 0; i < 4; ++i) level.spikes.push_back(cells[next++]);
    return level;
}

/** Crea los objetos del nivel nuevo a partir de sus datos serializables. */
inline void GenerateNewLevel(Scene& scene)
{
    RestoreLevel(scene, GenerateNewLevelData());
}

// La captura se realiza al guardar; no se hacen snapshots por fotograma.
