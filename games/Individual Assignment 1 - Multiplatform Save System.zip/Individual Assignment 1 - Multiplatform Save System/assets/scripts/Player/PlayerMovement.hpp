#pragma once

#include <XEngine.h>
#include <cmath>

class PlayerMovement final : public Behaviour
{
public:
    float speed = 5.0f;

    void Update(float dt) override
    {
        const auto* action = Input->FindAction("Gameplay/Move");
        if (!action) return;

        Vec2 direction = action->ReadVec2(0);
        const float length = std::sqrt(direction.x * direction.x +
                                       direction.y * direction.y);
        if (length > 1.0f) {
            direction.x /= length;
            direction.y /= length;
        }

        transform->Translate(Vec3{
            direction.x * speed * dt,
            direction.y * speed * dt,
            0.0f
        });
    }
};
