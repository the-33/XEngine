#pragma once

#include <XEngine.h>
#include <algorithm>
#include <cmath>

class PlayerMovement final : public Behaviour
{
public:
    float speed = 5.0f;
    float knockbackSpeed = 8.0f;
    float knockbackDuration = 0.24f;

    // Se bloquea el movimiento brevemente para conservar el impulso del golpe.
    void Knockback(Vec2 direction)
    {
        const float length = std::sqrt(direction.x * direction.x +
                                       direction.y * direction.y);
        if (length < 0.0001f) return;

        direction.x /= length;
        direction.y /= length;

        knockbackRemaining_ = knockbackDuration;
        if (auto* body = gameObject->GetComponent<RigidBody2D>())
            body->velocity = Vec2{direction.x * knockbackSpeed,
                                  direction.y * knockbackSpeed};
    }

    void Update(float dt) override
    {
        auto* body = gameObject->GetComponent<RigidBody2D>();
        if (!body) return;

        if (knockbackRemaining_ > 0.f) {
            knockbackRemaining_ = std::max(0.f, knockbackRemaining_ - dt);
            return;
        }

        const auto* action = Input->FindAction("Gameplay/Move");
        if (!action) {
            body->velocity = Vec2{0.f, 0.f};
            return;
        }

        Vec2 direction = action->ReadVec2(0);
        const float length = std::sqrt(direction.x * direction.x +
                                       direction.y * direction.y);
        if (length > 1.0f) {
            direction.x /= length;
            direction.y /= length;
        }

        // La velocidad del cuerpo físico permite resolver contactos sólidos.
        body->velocity = Vec2{direction.x * speed, direction.y * speed};
    }

private:
    float knockbackRemaining_ = 0.f;
};
