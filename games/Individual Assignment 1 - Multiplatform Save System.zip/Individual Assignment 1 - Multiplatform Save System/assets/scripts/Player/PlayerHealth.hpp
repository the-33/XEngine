#pragma once

#include <XEngine.h>
#include "PlayerMovement.hpp"
#include <algorithm>
#include <string>

class PlayerHealth final : public Behaviour
{
public:
    float health = 1.0f;

    void SetHealth(float value) { health = std::clamp(value, 0.0f, 1.0f); }
    void TakeDamage(float amount) { SetHealth(health - std::max(0.0f, amount)); }
    void Heal(float amount) { SetHealth(health + std::max(0.0f, amount)); }
    bool IsDead() const { return health <= 0.0f; }

protected:
    void OnTriggerEnter(const CollisionInfo2D& info) override
    {
        GameObject* other = info.other;
        if (!other) return;

        const std::string type = other->tag.get();

        if (type == "Heart") {
            Heal(0.25f);
            other->tag = "Collected";
            other->Destroy();
        }
    }

    void OnCollisionEnter(const CollisionInfo2D& info) override
    {
        if (!info.other || info.other->tag.get() != "Spike") return;

        TakeDamage(0.25f);

        // La normal apunta hacia el obstáculo; se invierte para alejar al jugador.
        Vec2 away{1.f, 0.f};
        if (!info.contacts.empty()) {
            away = Vec2{-info.contacts.front().normalA.x,
                        -info.contacts.front().normalA.y};
        }
        else {
            const Vec3 playerPos = transform->position.get();
            const Vec3 spikePos = info.other->transform->position.get();
            away = Vec2{playerPos.x - spikePos.x, playerPos.y - spikePos.y};
        }

        if (auto* movement = gameObject->GetComponent<PlayerMovement>())
            movement->Knockback(away);
    }
};
