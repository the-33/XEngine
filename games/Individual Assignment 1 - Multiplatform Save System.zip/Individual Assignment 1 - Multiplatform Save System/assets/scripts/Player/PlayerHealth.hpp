#pragma once

#include <XEngine.h>
#include <algorithm>
#include <string>

class PlayerHealth final : public Behaviour
{
public:
    float health = 1.0f;

    void SetHealth(float value) { health = std::clamp(value, 0.0f, 1.0f); }
    void TakeDamage(float amount) { SetHealth(health - std::max(0.0f, amount)); }
    void Heal(float amount) { SetHealth(health + std::max(0.0f, amount)); }
    bool IsDead() const { return health <= 0.0f; }

protected:
    void OnTriggerEnter(const CollisionInfo2D& info) override
    {
        GameObject* other = info.other;
        if (!other) return;

        const std::string type = other->tag.get();

        if (type == "Heart") {
            Heal(0.25f);
            other->tag = "Collected";
            other->Destroy();
        }
        else if (type == "Spike") {
            TakeDamage(0.25f);
        }
    }
};
