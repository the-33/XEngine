#pragma once

#include <XEngine.h>
#include <XEngine/Serialization.h>
#include <cstdint>
#include <string>

struct Wallet
{
    std::uint32_t coins = 0;
    std::uint32_t gems = 0;

    XENGINE_SERIALIZABLE(coins, gems)
};

class PlayerWallet final : public Behaviour
{
public:
    Wallet wallet{};

protected:
    void OnTriggerEnter(const CollisionInfo2D& info) override
    {
        GameObject* other = info.other;
        if (!other) return;

        const std::string type = other->tag.get();
        if (type == "Coin") ++wallet.coins;
        else if (type == "Gem") ++wallet.gems;
        else return;

        other->tag = "Collected";
        other->Destroy();
    }
};
