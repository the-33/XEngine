#pragma once

#include <XEngine.h>
#include <XEngine/Serialization.h>
#include "PlayerHealth.hpp"
#include "PlayerWallet.hpp"

#include <string>

// Estado serializable del jugador, independiente de sus componentes Behaviour.
struct PlayerData
{
    std::string name = "Player";
    float health = 1.0f;
    Vec3 position{0.0f, 0.0f, 0.0f};
    Wallet wallet{};

    XENGINE_SERIALIZABLE(name, health, position, wallet)
};

inline PlayerData CapturePlayer(GameObject& player)
{
    PlayerData data{};
    data.name = player.name.get();
    data.position = player.transform->position.get();

    if (auto* health = player.GetComponent<PlayerHealth>())
        data.health = health->health;
    if (auto* wallet = player.GetComponent<PlayerWallet>())
        data.wallet = wallet->wallet;
    return data;
}

inline void RestorePlayer(GameObject& player, const PlayerData& data)
{
    player.name = data.name;
    player.transform->position = data.position;

    if (auto* health = player.GetComponent<PlayerHealth>())
        health->SetHealth(data.health);
    if (auto* wallet = player.GetComponent<PlayerWallet>())
        wallet->wallet = data.wallet;
}
