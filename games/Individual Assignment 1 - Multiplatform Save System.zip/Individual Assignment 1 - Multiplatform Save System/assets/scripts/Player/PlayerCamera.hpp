#pragma once

#include <XEngine.h>

// La cámara sigue al jugador; el suelo permanece fijo en coordenadas del mundo.
class PlayerCamera final : public Behaviour
{
public:
    void Update(float) override
    {
        Scene* activeScene = scene.get();
        if (!activeScene || !activeScene->camera.get()) return;

        const Vec3 position = transform->position.get();
        activeScene->camera->center = Vec2{position.x, position.y};
    }
};
