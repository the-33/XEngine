#pragma once

#include <XEngine.h>
#include "PlayerHealth.hpp"
#include "PlayerWallet.hpp"

#include <algorithm>
#include <string>

class PlayerHUD final : public Behaviour
{
public:
    GameObject* player = nullptr; // Referencia local a la escena.

    void Render() override
    {
        if (!player || !UI) return;
        const auto* health = player->GetComponent<PlayerHealth>();
        const auto* wallet = player->GetComponent<PlayerWallet>();
        if (!health || !wallet) return;

        const float health01 = std::clamp(health->health, 0.0f, 1.0f);
        const int percent = static_cast<int>(health01 * 100.f + 0.5f);

        // Los controles anclados conservan su posición al cambiar el tamaño.
        UI->Panel(UIRectTransform::TopLeft({280.f, 84.f}, {16.f, 16.f}),
                  Color{16, 24, 36, 224}, Color{69, 102, 120, 255});
        UI->Label("HEALTH  " + std::to_string(percent) + "%",
                  UIRectTransform::TopLeft({240.f, 24.f}, {31.f, 25.f}),
                  AlignH::Left, AlignV::Middle);
        UI->ProgressBar(health01,
                        UIRectTransform::TopLeft({238.f, 22.f}, {31.f, 58.f}),
                        Color{36, 42, 51, 255}, Color{208, 78, 87, 255},
                        Color{149, 164, 174, 255});

        UI->Panel(UIRectTransform::TopRight({210.f, 116.f}, {16.f, 16.f}),
                  Color{16, 24, 36, 224}, Color{69, 102, 120, 255});
        UI->Label("WALLET", UIRectTransform::TopRight({172.f, 24.f}, {35.f, 24.f}),
                  AlignH::Center, AlignV::Middle);
        UI->Label("Coins: " + std::to_string(wallet->wallet.coins),
                  UIRectTransform::TopRight({166.f, 22.f}, {37.f, 62.f}),
                  AlignH::Left, AlignV::Middle);
        UI->Label("Gems: " + std::to_string(wallet->wallet.gems),
                  UIRectTransform::TopRight({166.f, 22.f}, {37.f, 94.f}),
                  AlignH::Left, AlignV::Middle);

    }
};
