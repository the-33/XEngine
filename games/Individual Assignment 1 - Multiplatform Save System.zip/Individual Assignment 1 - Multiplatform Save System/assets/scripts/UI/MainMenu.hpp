#pragma once

#include <XEngine.h>

#include "OptionsPanel.hpp"
#include "GameUILayout.hpp"
#include "../Save/GameSaveFiles.hpp"
#include "../Save/GameSaveSlots.hpp"

#include <algorithm>
#include <array>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <string>
#include <utility>
#include <vector>

/** Menú principal con selección de slots, opciones e importación de partidas. */
class MainMenu final : public Behaviour
{
public:
    OptionsPanel* optionsPanel = nullptr; // Referencia local al panel reutilizable.

    void Update(float) override
    {
        if (!Input) return;
        if (waitingForEscapeRelease_) {
            if (!Input->KeyDown(Key::ESCAPE)) waitingForEscapeRelease_ = false;
            return;
        }
        if (UI && UI->DropdownConsumedCancel()) return;

        const InputAction* action = Input->IsActionMapEnabled("UI", 0)
            ? Input->FindAction("UI/Cancel") : nullptr;
        const bool cancel = (action && action->WasPressedThisFrame(0)) ||
                            Input->KeyPressed(Key::ESCAPE);
        if (!cancel) return;

        // Escape termina la edición antes de abandonar el panel actual.
        if ((screen_ == Screen::Import || screen_ == Screen::NewGame) && wasEditingText_) {
            wasEditingText_ = false;
            return;
        }
        if (screen_ == Screen::Import) screen_ = Screen::Slots;
        else if (screen_ == Screen::NewGame) screen_ = Screen::Slots;
        else if (screen_ == Screen::Slots) screen_ = Screen::Home;
        if (UI) UI->ClearFocus();
    }

    void Render() override
    {
        if (!UI) return;
        switch (screen_) {
        case Screen::Home: RenderHome(); break;
        case Screen::Slots: RenderSlots(); break;
        case Screen::Import: RenderImport(); break;
        case Screen::NewGame: RenderNewGame(); break;
        }
        wasEditingText_ = UI->IsEditingText();
    }

protected:
    void OnEnable() override
    {
        if (Input) {
            // Cada panel activo mantiene una sola instancia del contexto Menu.
            if (!Input->IsActionMapEnabled("UI", 0) &&
                Input->PushActionContext(0, "Menu"))
                ownsMenuContext_ = true;
            if (Input->KeyDown(Key::ESCAPE)) waitingForEscapeRelease_ = true;
        }
    }

    void OnDisable() override
    {
        if (ownsMenuContext_ && Input) Input->PopActionContext(0);
        ownsMenuContext_ = false;
    }

private:
    enum class Screen { Home, Slots, Import, NewGame };

    struct SlotView
    {
        bool free = false;
        bool loadable = false;
        std::string name{};
        std::string date{};
        std::string playTime{};
    };

    /** Resume una duración en horas y minutos para el panel de slots. */
    static std::string FormatPlayTime(double seconds)
    {
        const auto minutes = static_cast<std::uint64_t>(
            std::max(0.0, std::min(seconds / 60.0, 1.0e12)));
        return std::to_string(minutes / 60) + "h " + std::to_string(minutes % 60) + "m";
    }

    /** Actualiza los metadatos al abrir la selección o regresar de importar. */
    void RefreshSlots()
    {
        for (int index = 0; index < GameSaveSlots::Count; ++index) {
            SlotView next{};
            const auto path = GameSaveSlots::PathFor(index + 1);
            if (path.empty()) {
                next.name = "Save directory unavailable";
            } else if (GameSaveSlots::IsFree(index + 1)) {
                next.free = true;
                next.name = "New Game";
            } else {
                GameSaveData data{};
                const GameSaveResult result = GameSaveFiles::ReadSlot(path, data);
                if (result.Ok()) {
                    next.loadable = true;
                    next.name = data.player.name.empty() ? "Player" : data.player.name;
                    next.date = data.metadata.savedAtUtc.empty()
                        ? "Unknown save date" : data.metadata.savedAtUtc;
                    next.playTime = "Played: " + FormatPlayTime(data.metadata.playTimeSeconds);
                    if (result.usedBackup || result.usedTemporary)
                        next.playTime += " (recovered)";
                } else {
                    next.name = result.status == GameSaveStatus::FutureVersion
                        ? "Newer save version" : "Damaged or unreadable save";
                    next.date = result.message;
                }
            }
            slots_[static_cast<std::size_t>(index)] = std::move(next);
        }
    }

    /** Entra en el juego después de preparar la carga o el nuevo slot. */
    void EnterGame()
    {
        if (Scenes && Scenes->SetActive("GameScene")) return;
        status_ = "Could not open game scene";
    }

    /** Carga un slot ocupado o permite crear uno nuevo con nombre. */
    void ChooseSlot(int slot)
    {
        if (slot < 1 || slot > GameSaveSlots::Count) return;
        const auto path = GameSaveSlots::PathFor(slot);
        if (path.empty()) { status_ = "Save directory unavailable"; return; }

        const SlotView& view = slots_[static_cast<std::size_t>(slot - 1)];
        if (view.free) {
            if (!GameSaveSlots::IsFree(slot)) {
                RefreshSlots();
                status_ = "Slot changed; select it again";
                return;
            }
            newGameSlot_ = slot;
            newGameName_.clear();
            status_.clear();
            screen_ = Screen::NewGame;
            if (UI) UI->ClearFocus();
        } else if (view.loadable) {
            const GameSaveResult result = GameSaveFiles::Load(path);
            if (result.Ok()) EnterGame();
            else { status_ = result.message; RefreshSlots(); }
        } else {
            status_ = "This slot cannot be loaded";
        }
    }

    /** Rellena el desplegable con los slots que no contienen ningún candidato. */
    void OpenImport()
    {
        RefreshSlots();
        importChoices_ = {"Do not save (view only)"};
        importSlotNumbers_ = {0};
        for (int index = 1; index <= GameSaveSlots::Count; ++index) {
            if (slots_[static_cast<std::size_t>(index - 1)].free) {
                importChoices_.push_back("Slot " + std::to_string(index));
                importSlotNumbers_.push_back(index);
            }
        }
        importChoice_ = 0;
        status_.clear();
        screen_ = Screen::Import;
        if (UI) UI->ClearFocus();
    }

    /** Importa los datos sin sobreescribir el archivo original. */
    void ImportGame()
    {
        if (importPath_.empty()) { status_ = "Enter the path of a save file"; return; }
        GameSaveData imported{};
        GameSaveResult result{};
        try {
            // Las rutas copiadas desde el explorador o la consola pueden llevar comillas.
            std::string path = importPath_;
            const auto first = path.find_first_not_of(" \t\r\n");
            if (first == std::string::npos) { status_ = "Enter the path of a save file"; return; }
            const auto last = path.find_last_not_of(" \t\r\n");
            path = path.substr(first, last - first + 1);
            if (path.size() >= 2 && path.front() == '"' && path.back() == '"')
                path = path.substr(1, path.size() - 2);
            // El campo contiene UTF-8; char8_t conserva su codificación en Windows.
            const std::u8string utf8Path(path.begin(), path.end());
            result = GameSaveFiles::ReadSlot(std::filesystem::path(utf8Path), imported, false);
        } catch (const std::exception&) {
            status_ = "Invalid file path";
            return;
        }
        if (!result.Ok()) { status_ = result.message; return; }

        if (importChoice_ < 0 ||
            static_cast<std::size_t>(importChoice_) >= importSlotNumbers_.size()) {
            status_ = "Invalid destination";
            return;
        }
        const int destination = importSlotNumbers_[static_cast<std::size_t>(importChoice_)];
        if (destination == 0) {
            // El archivo importado se consulta, pero no queda asociado a Save.
            GameSession::Get().QueueLoadedGame(std::move(imported));
            EnterGame();
            return;
        }

        if (!GameSaveSlots::IsFree(destination)) {
            OpenImport();
            status_ = "Destination slot is no longer empty";
            return;
        }

        const auto path = GameSaveSlots::PathFor(destination);
        const GameSaveResult saved = GameSaveFiles::Save(std::move(imported), path);
        if (!saved.Ok()) { status_ = saved.message; return; }
        if (const GameSaveData* current = GameSession::Get().Current())
            GameSession::Get().QueueLoadedGame(*current, path);
        EnterGame();
    }

    /** Confirma el nombre y guarda el estado inicial antes de entrar al juego. */
    void CreateNamedGame()
    {
        const auto first = newGameName_.find_first_not_of(" \t\r\n");
        if (first == std::string::npos) {
            status_ = "Enter a player name";
            return;
        }
        const auto last = newGameName_.find_last_not_of(" \t\r\n");
        const std::string name = newGameName_.substr(first, last - first + 1);
        const auto path = GameSaveSlots::PathFor(newGameSlot_);
        if (path.empty() || !GameSaveSlots::IsFree(newGameSlot_)) {
            status_ = "Slot is no longer available";
            return;
        }
        GameSaveData initial{};
        initial.player.name = name;
        initial.level = GenerateNewLevelData();
        const GameSaveResult saved = GameSaveFiles::Save(std::move(initial), path);
        if (!saved.Ok()) {
            status_ = saved.message;
            return;
        }
        // La escena carga exactamente el nivel que acaba de quedar en el slot.
        if (const GameSaveData* current = GameSession::Get().Current())
            GameSession::Get().QueueLoadedGame(*current, path);
        EnterGame();
    }

    void RenderHome()
    {
        const Rect frame = UI->Resolve(UIRectTransform::Center({480.f, 410.f}));
        UI->Panel(frame, Color{17, 27, 39, 246}, Color{107, 145, 165, 255});
        UI->Label("MULTIPLATFORM SAVE SYSTEM",
                  GameUILayout::At(24.f, 20.f, 432.f, 60.f),
                  AlignH::Center, AlignV::Middle, -1.f, &frame);

        if (UI->Button("menu.play", GameUILayout::At(90.f, 112.f, 300.f, 55.f), "Play", &frame)) {
            status_.clear();
            RefreshSlots();
            screen_ = Screen::Slots;
            UI->ClearFocus();
            return;
        }
        if (UI->Button("menu.options", GameUILayout::At(90.f, 200.f, 300.f, 55.f), "Options", &frame) &&
            optionsPanel) {
            optionsPanel->Open(gameObject.get());
            return;
        }
        if (UI->Button("menu.exit", GameUILayout::At(90.f, 288.f, 300.f, 55.f), "Exit", &frame))
            Engine::Stop();
    }

    void RenderSlots()
    {
        const Rect frame = UI->Resolve(UIRectTransform::Center({760.f, 600.f}));
        UI->Panel(frame, Color{17, 27, 39, 246}, Color{107, 145, 165, 255});
        UI->Label("SELECT SAVE SLOT", GameUILayout::At(30.f, 15.f, 700.f, 45.f),
                  AlignH::Center, AlignV::Middle, -1.f, &frame);

        constexpr const char* buttons[]{"menu.slot1", "menu.slot2", "menu.slot3"};
        for (int index = 0; index < GameSaveSlots::Count; ++index) {
            const float top = 75.f + index * 122.f;
            const SlotView& slot = slots_[static_cast<std::size_t>(index)];
            const std::string buttonText = "Slot " + std::to_string(index + 1) +
                (slot.free ? ": New Game" : ": Load");
            if (UI->Button(buttons[index], GameUILayout::At(31.f, top, 248.f, 85.f), buttonText, &frame)) {
                ChooseSlot(index + 1);
                return;
            }
            UI->Label(slot.name, GameUILayout::At(299.f, top - 3.f, 430.f, 29.f),
                      AlignH::Left, AlignV::Middle, -1.f, &frame);
            if (!slot.date.empty())
                UI->Label(slot.date, GameUILayout::At(299.f, top + 25.f, 430.f, 27.f),
                          AlignH::Left, AlignV::Middle, -1.f, &frame);
            if (!slot.playTime.empty())
                UI->Label(slot.playTime, GameUILayout::At(299.f, top + 52.f, 430.f, 27.f),
                          AlignH::Left, AlignV::Middle, -1.f, &frame);
        }

        if (UI->Button("menu.import", GameUILayout::At(45.f, 475.f, 305.f, 50.f),
                       "Import Save", &frame)) { OpenImport(); return; }
        if (UI->Button("menu.slots.back", GameUILayout::At(410.f, 475.f, 305.f, 50.f),
                       "Back", &frame)) { screen_ = Screen::Home; status_.clear(); UI->ClearFocus(); return; }
        if (!status_.empty())
            UI->Label(status_, GameUILayout::At(30.f, 551.f, 700.f, 30.f),
                      AlignH::Center, AlignV::Middle, -1.f, &frame);
    }

    void RenderImport()
    {
        const Rect frame = UI->Resolve(UIRectTransform::Center({780.f, 450.f}));
        UI->Panel(frame, Color{17, 27, 39, 246}, Color{107, 145, 165, 255});
        UI->Label("IMPORT SAVE", GameUILayout::At(30.f, 14.f, 720.f, 45.f),
                  AlignH::Center, AlignV::Middle, -1.f, &frame);
        UI->Label("File path", GameUILayout::At(42.f, 81.f, 180.f, 28.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);
        UI->TextInput("menu.import.path", GameUILayout::At(42.f, 112.f, 696.f, 47.f),
                      &importPath_, "Path to an existing save file", 1024, &frame);

        UI->Label("Destination", GameUILayout::At(42.f, 197.f, 182.f, 35.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);
        UI->Dropdown("menu.import.destination",
                     GameUILayout::At(236.f, 194.f, 460.f, 43.f),
                     &importChoice_, importChoices_, 4, &frame);
        UI->Label("Without a slot, the imported game can be played but not saved.",
                  GameUILayout::At(42.f, 257.f, 696.f, 30.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);

        if (UI->Button("menu.import.load", GameUILayout::At(65.f, 323.f, 294.f, 47.f),
                       "Load Game", &frame)) { ImportGame(); return; }
        if (UI->Button("menu.import.back", GameUILayout::At(422.f, 323.f, 294.f, 47.f),
                       "Back", &frame)) { screen_ = Screen::Slots; status_.clear(); UI->ClearFocus(); return; }
        if (!status_.empty())
            UI->Label(status_, GameUILayout::At(24.f, 389.f, 732.f, 45.f),
                      AlignH::Center, AlignV::Middle, -1.f, &frame);
    }

    /** Panel de nombre que escribe el slot cuando se confirma Create. */
    void RenderNewGame()
    {
        const Rect frame = UI->Resolve(UIRectTransform::Center({520.f, 340.f}));
        UI->Panel(frame, Color{17, 27, 39, 246}, Color{107, 145, 165, 255});
        UI->Label("NEW GAME - SLOT " + std::to_string(newGameSlot_),
                  GameUILayout::At(25.f, 18.f, 470.f, 48.f),
                  AlignH::Center, AlignV::Middle, -1.f, &frame);
        UI->Label("Player name", GameUILayout::At(48.f, 91.f, 424.f, 30.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);
        UI->TextInput("menu.newgame.name", GameUILayout::At(48.f, 128.f, 424.f, 48.f),
                      &newGameName_, "Enter your name", 32, &frame);
        if (UI->Button("menu.newgame.create", GameUILayout::At(48.f, 214.f, 195.f, 48.f),
                       "Create", &frame)) { CreateNamedGame(); return; }
        if (UI->Button("menu.newgame.back", GameUILayout::At(277.f, 214.f, 195.f, 48.f),
                       "Back", &frame)) {
            screen_ = Screen::Slots;
            status_.clear();
            UI->ClearFocus();
            return;
        }
        if (!status_.empty())
            UI->Label(status_, GameUILayout::At(35.f, 285.f, 450.f, 32.f),
                      AlignH::Center, AlignV::Middle, -1.f, &frame);
    }

    Screen screen_ = Screen::Home;
    std::array<SlotView, GameSaveSlots::Count> slots_{};
    std::vector<int> importSlotNumbers_{};
    std::vector<std::string> importChoices_{};
    std::string importPath_{};
    std::string newGameName_{};
    std::string status_{};
    int importChoice_ = 0;
    int newGameSlot_ = 0;
    bool ownsMenuContext_ = false;
    bool waitingForEscapeRelease_ = false;
    bool wasEditingText_ = false;
};
