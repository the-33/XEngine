#pragma once

#include <XEngine.h>
#include "OptionsPanel.hpp"
#include "GameUILayout.hpp"
#include "../Save/GameSession.hpp"
#include "../Save/GameSaveFiles.hpp"

// Menú de pausa propio de GameScene; permanece activo para detectar Escape.
class GamePauseMenu final : public Behaviour
{
public:
    OptionsPanel* optionsPanel = nullptr; // Puntero no propietario al panel de opciones.

    void Update(float dt) override
    {
        // Solo se incrementa el tiempo jugado; no se captura la escena cada frame.
        GameSession::Get().AdvancePlayTime(static_cast<double>(dt));
        if (!Input) return;

        // Los dos dispositivos deben soltar Pause antes de cambiar de contexto.
        // Así una pulsación mantenida no crea otro flanco al activar un mapa.
        if (waitingForPauseRelease_) {
            if (!PauseControlHeld())
                waitingForPauseRelease_ = false;
            return;
        }

        const bool uiMode = open_;
        const char* map = uiMode ? "UI" : "Global";
        const char* path = uiMode ? "UI/Cancel" : "Global/Pause";
        const InputAction* action = Input->IsActionMapEnabled(map, 0)
            ? Input->FindAction(path) : nullptr;
        const bool requested = (action && action->WasPressedThisFrame(0)) ||
                               Input->KeyPressed(Key::ESCAPE);

        if (requested) {
            waitingForPauseRelease_ = PauseControlHeld();
            if (open_) Close();
            else Open();
        }
    }

    void Render() override
    {
        if (!open_ || !UI) return;

        const Rect frame = UI->Resolve(UIRectTransform::Center({380.f, 322.f}));
        UI->Panel(frame, Color{17, 27, 39, 246}, Color{107, 145, 165, 255});
        UI->Label("PAUSED", GameUILayout::At(24.f, 18.f, 332.f, 45.f),
                  AlignH::Center, AlignV::Middle, -1.f, &frame);

        if (UI->Button("pause.save",
                       GameUILayout::At(64.f, 86.f, 252.f, 48.f), "Save", &frame)) {
            Scene* activeScene = scene.get();
            saveMessage_ = activeScene
                ? GameSaveFiles::SaveScene(*activeScene).message
                : "No active scene to save";
        }

        if (UI->Button("pause.mainMenu",
                       GameUILayout::At(64.f, 160.f, 252.f, 48.f), "Main Menu", &frame)) {
            // El cierre restaura el tiempo y el contexto Playing antes del cambio.
            Close();
            if (Scenes) Scenes->SetActive("MainMenu");
            return;
        }

        if (UI->Button("pause.options",
                       GameUILayout::At(64.f, 234.f, 252.f, 48.f), "Options", &frame) &&
            optionsPanel)
            optionsPanel->Open(gameObject.get());

        if (!saveMessage_.empty())
            UI->Label(saveMessage_, GameUILayout::At(10.f, 288.f, 360.f, 29.f),
                      AlignH::Center, AlignV::Middle, -1.f, &frame);
    }

protected:
    void OnEnable() override
    {
        // La opción de volver mantiene el bloqueo hasta soltar Escape o Start.
        if (open_ && PauseControlHeld())
            waitingForPauseRelease_ = true;
    }

    void OnDestroy() override
    {
        // La escala temporal se restaura incluso si se descarga la escena.
        if (open_) Close();
    }

private:
    /** Comprueba el estado físico de las teclas de pausa, no el mapa activo. */
    bool PauseControlHeld() const
    {
        if (!Input) return false;
        if (Input->KeyDown(Key::ESCAPE)) return true;
        for (GamepadId id : Input->GetConnectedGamepads())
            if (Input->GamepadDown(id, GamepadButton::Start)) return true;
        return false;
    }

    void Open()
    {
        if (open_) return;
        open_ = true;
        if (Time) {
            previousTimeScale_ = Time->timeScale.get();
            Time->timeScale = 0.f;
        }
        if (Input && Input->PushActionContext(0, "Menu"))
            ownsMenuContext_ = true;
        if (UI) UI->ClearFocus();
    }

    void Close()
    {
        if (!open_) return;
        open_ = false;
        if (ownsMenuContext_ && Input) Input->PopActionContext(0);
        ownsMenuContext_ = false;
        if (Time) Time->timeScale = previousTimeScale_;
        if (UI) UI->ClearFocus();
    }

    float previousTimeScale_ = 1.f;
    bool open_ = false;
    bool ownsMenuContext_ = false;
    bool waitingForPauseRelease_ = false; // Evita nuevos flancos por cambio de contexto.
    std::string saveMessage_{};
};
