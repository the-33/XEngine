#pragma once

#include <XEngine.h>
#include "GameOptionsStore.hpp"
#include "GameUILayout.hpp"

#include <string>
#include <utility>
#include <vector>

// Panel de opciones reutilizable, independiente del menú que lo abre.
// El panel anterior pertenece a la misma escena.
class OptionsPanel final : public Behaviour
{
public:
    void Open(GameObject* previousPanel)
    {
        GameObject* self = gameObject.get();
        if (!self || previousPanel == self) return;
        if (self->activeInHierarchy) return;

        EnsureCache(); // PlayerPrefs se consulta solo en la primera apertura.
        RefreshResolutions(); // El monitor activo puede haber cambiado.

        previousPanel_ = previousPanel;
        if (previousPanel_) previousPanel_->SetActive(false);

        // Se reutiliza el contexto UI si el menú anterior ya lo activó.
        if (Input && !Input->IsActionMapEnabled("UI", 0) &&
            Input->PushActionContext(0, "Menu"))
            ownsMenuContext_ = true;

        self->SetActive(true);
        // El foco pasa al panel recién abierto.
        if (UI) UI->ClearFocus();
    }

    void Back()
    {
        // Back recupera los valores confirmados y descarta la edición pendiente.
        if (Sound) Sound->SetMasterVolume(cache_.saved.volume);
        ResetDraft();
        wasEditingText_ = false;

        GameObject* previous = std::exchange(previousPanel_, nullptr);
        gameObject->SetActive(false);
        if (ownsMenuContext_ && Input) Input->PopActionContext(0);
        ownsMenuContext_ = false;
        if (previous) previous->SetActive(true);
        if (UI) UI->ClearFocus();
    }

    void Update(float) override
    {
        if (!Input) return;
        if (UI && UI->DropdownConsumedCancel()) return; // Escape cerró solo la lista.
        const InputAction* cancel = Input->IsActionMapEnabled("UI", 0)
            ? Input->FindAction("UI/Cancel") : nullptr;
        const bool pressed = (cancel && cancel->WasPressedThisFrame(0)) ||
                             Input->KeyPressed(Key::ESCAPE);
        if (!pressed) return;

        // Escape termina la edición de texto sin cerrar el panel en ese frame.
        if (wasEditingText_) {
            wasEditingText_ = false;
            return;
        }
        Back();
    }

    void Render() override
    {
        if (!UI) return;

        const Rect frame = UI->Resolve(UIRectTransform::Center({610.f, 468.f}));
        UI->Panel(frame, Color{17, 27, 39, 246}, Color{107, 145, 165, 255});
        UI->Label("OPTIONS", GameUILayout::At(26.f, 21.f, 558.f, 38.f),
                  AlignH::Center, AlignV::Middle, -1.f, &frame);

        UI->Label("Volume", GameUILayout::At(42.f, 80.f, 110.f, 32.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);
        if (UI->Slider("options.volume", GameUILayout::At(151.f, 79.f, 366.f, 38.f),
                       &cache_.volume, 0.f, 1.f, 0.05f, &frame)) {
            if (Sound) Sound->SetMasterVolume(cache_.volume); // Previsualización del volumen.
            status_.clear();
        }
        const int volumePercent = static_cast<int>(cache_.volume * 100.f + 0.5f);
        UI->Label(std::to_string(volumePercent) + "%",
                  GameUILayout::At(521.f, 80.f, 64.f, 32.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);

        UI->Label("Resolution", GameUILayout::At(42.f, 164.f, 154.f, 32.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);
        UI->Dropdown("options.resolution",
                     GameUILayout::At(208.f, 160.f, 294.f, 40.f),
                     &cache_.resolutionIndex, cache_.resolutionLabels, 6, &frame);

        UI->Label("Internal render resolution (windowed and fullscreen)",
                  GameUILayout::At(42.f, 207.f, 526.f, 24.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);

        UI->Label("Fullscreen", GameUILayout::At(42.f, 254.f, 164.f, 36.f),
                  AlignH::Left, AlignV::Middle, -1.f, &frame);
        UI->Toggle("options.fullscreen", GameUILayout::At(208.f, 250.f, 152.f, 44.f),
                   &cache_.fullscreen, "", &frame);

        if (UI->Button("options.save", GameUILayout::At(82.f, 357.f, 194.f, 48.f),
                       "Save", &frame))
            SaveToPrefs();
        if (UI->Button("options.back", GameUILayout::At(334.f, 357.f, 194.f, 48.f),
                       "Back", &frame)) {
            Back();
            return;
        }

        if (!status_.empty())
            UI->Label(status_, GameUILayout::At(36.f, 424.f, 538.f, 27.f),
                      AlignH::Center, AlignV::Middle, -1.f, &frame);

        wasEditingText_ = UI->IsEditingText();
    }

protected:
    void OnEnable() override { EnsureCache(); }

private:
    // El caché distingue los valores confirmados de los cambios provisionales.
    struct OptionsCache
    {
        bool initialized = false;
        OptionsData saved{};
        float volume = 0.8f;
        bool fullscreen = false;
        std::vector<Vec2I> resolutions;
        std::vector<std::string> resolutionLabels;
        int resolutionIndex = 0;
    };

    void EnsureCache()
    {
        if (cache_.initialized) return;
        cache_.saved = GameOptionsStore::Load();
        cache_.initialized = true;
        ResetDraft();
    }

    void ResetDraft()
    {
        cache_.volume = cache_.saved.volume;
        cache_.fullscreen = cache_.saved.windowMode == "Fullscreen";
        RefreshResolutions();
        status_.clear();
    }

    void RefreshResolutions()
    {
        const Vec2I monitor = Window ? Window->GetDesktopResolution() : Vec2I{1920, 1080};
        cache_.resolutions = GameOptionsStore::SuggestedResolutions(monitor);
        cache_.resolutionLabels.clear();
        cache_.resolutionIndex = 0;
        int bestDifference = 2147483647;
        for (std::size_t index = 0; index < cache_.resolutions.size(); ++index) {
            const Vec2I r = cache_.resolutions[index];
            cache_.resolutionLabels.push_back(std::to_string(r.x) + " x " + std::to_string(r.y));
            const int difference = std::abs(r.x - cache_.saved.resolution.x) +
                                   std::abs(r.y - cache_.saved.resolution.y);
            if (difference < bestDifference) {
                bestDifference = difference;
                cache_.resolutionIndex = static_cast<int>(index);
            }
        }
    }

    void SaveToPrefs()
    {
        if (cache_.resolutionIndex < 0 ||
            static_cast<std::size_t>(cache_.resolutionIndex) >= cache_.resolutions.size()) {
            status_ = "No resolution selected";
            return;
        }

        OptionsData edited = cache_.saved;
        edited.volume = cache_.volume;
        edited.resolution = cache_.resolutions[cache_.resolutionIndex];
        edited.windowMode = cache_.fullscreen ? "Fullscreen" : "Windowed";

        if (!GameOptionsStore::Apply(edited)) {
            GameOptionsStore::Apply(cache_.saved);
            status_ = "Render target unavailable or window mode rejected";
            return;
        }
        if (!GameOptionsStore::Save(edited)) {
            GameOptionsStore::Apply(cache_.saved);
            status_ = "Could not write PlayerPrefs";
            return;
        }

        cache_.saved = edited;
        status_ = "Options saved";

    }

    GameObject* previousPanel_ = nullptr;
    OptionsCache cache_{};
    bool ownsMenuContext_ = false;
    bool wasEditingText_ = false;
    std::string status_{};
};

inline OptionsPanel* CreateOptionsPanel(Scene& scene)
{
    GameObject* object = scene.CreateObject("OptionsPanel");
    if (!object) return nullptr;
    auto* panel = object->AddComponent<OptionsPanel>();
    object->SetActive(false);
    return panel;
}
