#pragma once

#include <XEngine.h>

// Los controles interiores se anclan al borde superior izquierdo de su panel.
// El tamaño y los márgenes se escalan con el UICanvas del motor.
namespace GameUILayout
{
    inline UIRectTransform At(float x, float y, float width, float height) noexcept
    {
        return UIRectTransform::TopLeft({width, height}, {x, y});
    }
}
