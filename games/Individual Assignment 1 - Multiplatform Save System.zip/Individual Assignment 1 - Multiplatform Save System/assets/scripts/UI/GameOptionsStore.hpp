#pragma once

#include <XEngine.h>

#include <algorithm>
#include <cmath>
#include <vector>
#include <string>

// Las opciones de aplicación no forman parte del guardado de la partida.
struct OptionsData
{
    float volume = 0.8f;
    Vec2I resolution{1280, 720}; // Resolución interna de renderizado en ambos modos.
    std::string windowMode = "Windowed";
};

// Las preferencias son comunes a todos los slots y a los distintos menús.
namespace GameOptionsStore
{
    inline constexpr const char* kVolume = "options.volume";
    inline constexpr const char* kWidth = "options.width";
    inline constexpr const char* kHeight = "options.height";
    inline constexpr const char* kFullscreen = "options.fullscreen";

    inline bool Initialize()
    {
        return PlayerPrefs::Initialize("XEngine", "IndividualAssignment1");
    }

    inline bool ValidResolution(int width, int height) noexcept
    {
        return width >= 320 && width <= 8192 &&
               height >= 240 && height <= 8192;
    }

    // Las resoluciones se ajustan al aspecto del monitor; no son modos de vídeo SDL.
    inline std::vector<Vec2I> SuggestedResolutions(Vec2I desktop)
    {
        if (!ValidResolution(desktop.x, desktop.y)) desktop = {1920, 1080};
        const double aspect = static_cast<double>(desktop.x) / desktop.y;
        std::vector<Vec2I> resolutions;
        const auto add = [&](int width, int height) {
            if (!ValidResolution(width, height) ||
                width > desktop.x || height > desktop.y ||
                std::fabs(static_cast<double>(width) / height - aspect) / aspect > 0.012)
                return;
            const auto duplicate = std::find_if(resolutions.begin(), resolutions.end(),
                [=](Vec2I r) { return r.x == width && r.y == height; });
            if (duplicate == resolutions.end()) resolutions.push_back({width, height});
        };

        add(desktop.x, desktop.y);
        // Se filtran formatos habituales con una tolerancia de aspecto del 1,2 %.
        const Vec2I common[] = {
            {3840, 2160}, {3440, 1440}, {2560, 1440}, {2560, 1080},
            {2560, 1600}, {1920, 1200}, {1920, 1080}, {1920, 800},
            {1680, 1050}, {1600, 1200}, {1600, 900}, {1440, 900},
            {1366, 768}, {1280, 1024}, {1280, 960}, {1280, 800},
            {1280, 720}, {1024, 768}, {1024, 576}, {960, 600},
            {960, 540}, {854, 480}, {800, 600}, {640, 480},
            {640, 400}, {640, 360}, {480, 270}
        };
        for (Vec2I r : common) add(r.x, r.y);

        // También se generan escalas de resoluciones nativas poco habituales.
        for (const double fraction : {0.75, 2.0 / 3.0, 0.5, 1.0 / 3.0, 0.25}) {
            const int width = 2 * static_cast<int>(std::lround(desktop.x * fraction / 2.0));
            const int height = 2 * static_cast<int>(std::lround(desktop.y * fraction / 2.0));
            add(width, height);
        }
        std::sort(resolutions.begin(), resolutions.end(), [](Vec2I a, Vec2I b) {
            return a.x * a.y > b.x * b.y;
        });
        return resolutions;
    }

    inline OptionsData CaptureCurrent()
    {
        OptionsData result{};
        if (Sound) result.volume = Sound->MasterVolume();
        if (Window) {
            result.resolution = Renderer ? Renderer->GetRenderResolution() : Window->GetSize();
            const bool fullscreen = Window->IsFullscreen();
            result.windowMode = fullscreen ? "Fullscreen" : "Windowed";
        }
        return result;
    }

    inline OptionsData Load()
    {
        OptionsData defaults = CaptureCurrent();
        OptionsData result = defaults;

        const float volume = PlayerPrefs::GetFloat(kVolume, defaults.volume);
        if (std::isfinite(volume))
            result.volume = std::clamp(volume, 0.f, 1.f);

        const int width = PlayerPrefs::GetInt(kWidth, defaults.resolution.x);
        const int height = PlayerPrefs::GetInt(kHeight, defaults.resolution.y);
        if (ValidResolution(width, height)) result.resolution = Vec2I{width, height};

        const bool currentFullscreen = defaults.windowMode == "Fullscreen";
        result.windowMode = PlayerPrefs::GetInt(kFullscreen, currentFullscreen ? 1 : 0)
            ? "Fullscreen" : "Windowed";
        return result;
    }

    inline bool Apply(const OptionsData& options)
    {
        if (!std::isfinite(options.volume) ||
            !ValidResolution(options.resolution.x, options.resolution.y)) return false;

        if (Sound) Sound->SetMasterVolume(std::clamp(options.volume, 0.f, 1.f));
        if (Window && Renderer) {
            const bool fullscreen = options.windowMode == "Fullscreen";
            // La textura interna se presenta escalada tanto en ventana como
            // en pantalla completa, sin cambiar los píxeles del monitor.
            Window->SetFullscreen(fullscreen);
            if (Window->IsFullscreen() != fullscreen) return false;
            if (!Renderer->SetRenderResolution(options.resolution.x,
                                               options.resolution.y)) return false;
        }
        return true;
    }

    inline bool Save(const OptionsData& options)
    {
        if (!std::isfinite(options.volume) ||
            !ValidResolution(options.resolution.x, options.resolution.y)) return false;

        const bool keysOk =
            PlayerPrefs::SetFloat(kVolume, std::clamp(options.volume, 0.f, 1.f)) &&
            PlayerPrefs::SetInt(kWidth, options.resolution.x) &&
            PlayerPrefs::SetInt(kHeight, options.resolution.y) &&
            PlayerPrefs::SetInt(kFullscreen, options.windowMode == "Fullscreen" ? 1 : 0);
        return keysOk && PlayerPrefs::Save();
    }
}
