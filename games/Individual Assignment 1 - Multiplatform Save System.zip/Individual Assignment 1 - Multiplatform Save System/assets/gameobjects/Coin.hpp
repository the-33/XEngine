#pragma once

#include <XEngine.h>

inline GameObject* CreateCoin(Scene& scene, Vec3 position = {})
{
    auto* coin = scene.CreateObject("Coin");
    if (!coin) return nullptr;
    coin->tag = "Coin";
    coin->transform->position = position;

    auto* sprite = coin->AddComponent<SpriteRenderer>();
    const Texture* texture = Assets->LoadTexture("textures/coin.png", 128.f);
    if (texture) sprite->sprite = texture;

    auto* collider = coin->AddComponent<Collider2D>();
    collider->shape = Collider2D::Shape::Circle;
    collider->isTrigger = true;
    collider->radius = 0.4f;
    if (texture) collider->FitToSprite(0.81f);

    return coin;
}
