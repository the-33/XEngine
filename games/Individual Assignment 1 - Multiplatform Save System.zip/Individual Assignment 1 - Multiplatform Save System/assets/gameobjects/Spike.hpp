#pragma once

#include <XEngine.h>

inline GameObject* CreateSpike(Scene& scene, Vec3 position = {})
{
    auto* spike = scene.CreateObject("Spike");
    if (!spike) return nullptr;
    spike->tag = "Spike";
    spike->transform->position = position;

    auto* sprite = spike->AddComponent<SpriteRenderer>();
    const Texture* texture = Assets->LoadTexture("textures/spike.png", 128.f);
    if (texture) sprite->sprite = texture;

    auto* collider = spike->AddComponent<Collider2D>();
    collider->shape = Collider2D::Shape::Box;
    collider->isTrigger = false; // Obstáculo sólido que impide el paso.
    collider->size = Vec2{0.72f, 0.76f};
    if (texture) collider->FitToSprite(0.72f, 0.76f);

    auto* body = spike->AddComponent<RigidBody2D>();
    body->bodyType = RigidBody2D::BodyType::Static;

    return spike;
}
