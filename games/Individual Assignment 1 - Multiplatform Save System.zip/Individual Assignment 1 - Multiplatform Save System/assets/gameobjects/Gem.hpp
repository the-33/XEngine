#pragma once

#include <XEngine.h>

inline GameObject* CreateGem(Scene& scene, Vec3 position = {})
{
    auto* gem = scene.CreateObject("Gem");
    if (!gem) return nullptr;
    gem->tag = "Gem";
    gem->transform->position = position;

    auto* sprite = gem->AddComponent<SpriteRenderer>();
    const Texture* texture = Assets->LoadTexture("textures/gem.png", 128.f);
    if (texture) sprite->sprite = texture;

    auto* collider = gem->AddComponent<Collider2D>();
    collider->shape = Collider2D::Shape::Box;
    collider->rotationOffset = 45.f;
    collider->isTrigger = true;
    collider->size = Vec2{0.57f, 0.57f};
    if (texture) collider->FitToSprite(0.57f);

    return gem;
}
