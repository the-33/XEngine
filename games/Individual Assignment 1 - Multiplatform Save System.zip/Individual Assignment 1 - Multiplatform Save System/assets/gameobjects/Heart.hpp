#pragma once

#include <XEngine.h>

inline GameObject* CreateHeart(Scene& scene, Vec3 position = {})
{
    auto* heart = scene.CreateObject("Heart");
    if (!heart) return nullptr;
    heart->tag = "Heart";
    heart->transform->position = position;

    auto* sprite = heart->AddComponent<SpriteRenderer>();
    const Texture* texture = Assets->LoadTexture("textures/heart.png", 128.f);
    if (texture) sprite->sprite = texture;

    auto* collider = heart->AddComponent<Collider2D>();
    collider->shape = Collider2D::Shape::Circle;
    collider->isTrigger = true;
    collider->radius = 0.35f;
    if (texture) collider->FitToSprite(0.70f);

    return heart;
}
