#pragma once

#include <XEngine.h>
#include "../scripts/Player/PlayerMovement.hpp"
#include "../scripts/Player/PlayerHealth.hpp"
#include "../scripts/Player/PlayerWallet.hpp"

#include <string>

inline GameObject* CreatePlayer(
    Scene& scene,
    const std::string& playerName = "Player",
    Vec3 position = {0.0f, 0.0f, 0.0f})
{
    auto* player = scene.CreateObject(playerName);
    if (!player) return nullptr;

    player->tag = "Player";
    player->transform->position = position;

    auto* sprite = player->AddComponent<SpriteRenderer>();
    const Texture* texture = Assets->LoadTexture("textures/player_capsule.png", 80.f);
    if (texture) sprite->sprite = texture;
    sprite->tint = Color{255, 255, 255, 255};

    auto* collider = player->AddComponent<Collider2D>();
    collider->shape = Collider2D::Shape::Capsule;
    collider->isTrigger = false;
    collider->size = Vec2{0.8f, 1.6f}; // Tamaño alternativo si no se carga la textura.
    if (texture) collider->FitToSprite(0.84f, 0.94f);

    // El cuerpo dinámico permite resolver las colisiones y el retroceso.
    // El movimiento cenital no necesita gravedad ni rotación.
    auto* body = player->AddComponent<RigidBody2D>();
    body->bodyType = RigidBody2D::BodyType::Dynamic;
    body->gravityScale = 0.f;
    body->constraints = RigidBody2D::Constraints::FreezeRot;
    body->collisionDetection = RigidBody2D::CollisionDetection::Continuous;
    body->linearDamping = 6.f;

    player->AddComponent<PlayerMovement>();
    player->AddComponent<PlayerHealth>();
    player->AddComponent<PlayerWallet>();

    return player;
}
