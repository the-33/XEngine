#pragma once

#include <XEngine.h>
#include "../scripts/PlayerMovement.hpp"
#include "../scripts/PlayerHealth.hpp"
#include "../scripts/PlayerWallet.hpp"

#include <string>

inline GameObject* CreatePlayer(
    Scene& scene,
    const std::string& playerName = "Player",
    Vec3 position = {0.0f, 0.0f, 0.0f})
{
    auto* player = scene.CreateObject(playerName);
    if (!player) return nullptr;

    player->tag = "Player";
    player->transform->position = position;

    auto* sprite = player->AddComponent<SpriteRenderer>();
    const Texture* texture = Assets->LoadTexture("textures/capsule.png", 80.f);
    if (texture) sprite->sprite = texture;
    sprite->tint = Color{255, 255, 255, 255};

    auto* collider = player->AddComponent<Collider2D>();
    collider->shape = Collider2D::Shape::Capsule;
    collider->isTrigger = false;
    collider->size = Vec2{0.8f, 1.6f}; // fallback if the PNG cannot be loaded
    if (texture) collider->FitToSprite(0.84f, 0.94f);

    player->AddComponent<PlayerMovement>();
    player->AddComponent<PlayerHealth>();
    player->AddComponent<PlayerWallet>();

    return player;
}
