#pragma once

#include <XEngine.h>
#include <cstdio>
#include "GameScene.hpp"

// Load shared assets here before registering scenes, if needed.
inline void InitGame(Engine& engine)
{
    (void)engine;
    if (!Input->LoadInputSchemes("input/InputSchemes.json") ||
        !Input->LoadPlayerProfiles("input/Playerslayers.json") ||
        !Input->LoadActionAsset("input/InputActions.json"))
        std::fprintf(stderr, "[INPUT] %s\n", Input->GetInputError().c_str());
    else {
        Input->PushActionContext(0, "Playing");
    }
    Scenes->Register("GameScene", BuildGameScene);
    Scenes->SetActive("GameScene");
}
