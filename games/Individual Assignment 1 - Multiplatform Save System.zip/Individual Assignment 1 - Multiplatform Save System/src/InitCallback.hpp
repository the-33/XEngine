#pragma once

#include <XEngine.h>
#include <cstdio>
#include "GameScene.hpp"
#include "../assets/scenes/MainMenuScene.hpp"
#include "../assets/scripts/UI/GameOptionsStore.hpp"

// Inicialización de preferencias, acciones y escena inicial.
inline void InitGame(Engine& engine)
{
    (void)engine;
    if (UI) {
        UICanvas canvas{};
        canvas.scaleMode = UICanvasScaleMode::ScaleWithScreenSize;
        canvas.referenceResolution = {1280.f, 720.f};
        canvas.matchWidthOrHeight = 0.5f;
        UI->SetCanvas(canvas);
    }
    if (!GameOptionsStore::Initialize())
        std::fprintf(stderr, "[OPTIONS] Failed to initialize PlayerPrefs\n");
    else if (!GameOptionsStore::Apply(GameOptionsStore::Load()))
        std::fprintf(stderr, "[OPTIONS] Could not apply saved window settings\n");

    if (!Input->LoadInputSchemes("input/InputSchemes.json") ||
        !Input->LoadPlayerProfiles("input/Players.json") ||
        !Input->LoadActionAsset("input/InputActions.json"))
        std::fprintf(stderr, "[INPUT] %s\n", Input->GetInputError().c_str());
    else {
        Input->PushActionContext(0, "Playing");
    }
    Scenes->Register("GameScene", BuildGameScene);
    Scenes->Register("MainMenu", BuildMainMenuScene);
    Scenes->SetActive("MainMenu");
}
